LME Scrap PWA v2
対応: 銅・真鍮・アルミ。円は¥/kg、ドルは$/MT。GitHub Pagesのルートへ全ファイルを上書きしてCommitしてください。古いPWAが残る場合はSafariでPages URLを再読み込み、必要ならホーム画面から削除して再追加してください。LME価格は手入力式です。
